# Foody Alexa Skill

## About Foody

Draft readme for the foody Alexa skill.

## Deployment

## Usage



## ToDo

* Update Sample utterances
* Update intent schema
* Test cases
